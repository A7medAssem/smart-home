import 'package:flutter/material.dart';
import 'package:segment_display/segment_display.dart';

class LivingRoom extends StatefulWidget {
  const LivingRoom({Key key}) : super(key: key);

  @override
  _TemperaturePageState createState() => _TemperaturePageState();
}

class _TemperaturePageState extends State<LivingRoom> {
  double temp = 15;
  double air = 20;
  double curtain=20;
  bool _lights = false;
  bool _air = false;
  bool _curtain= false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo.shade50,
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.only(top: 18, left: 24, right: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.indigo,
                    ),
                  ),
                   RotatedBox(
                    quarterTurns: 135,
                    child: IconButton(
                      icon: Icon(Icons.control_point_duplicate),
                      color: Colors.indigo,
                      onPressed: (){
                        print("Icon Button clicked");
                      },
                    ),
                  )
                ],
              ),
              Expanded(
                child: ListView(
                  physics: const BouncingScrollPhysics(),
                  children: [

                    const SizedBox(height: 24),
                    const Center(
                      child: Text(
                        'Living Room',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.black54,
                            fontSize: 25,
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 24),
                            child: Text(
                              'Light Mode',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,

                              ),
                            ),
                          ),
                          SwitchListTile(
                            value: _lights,
                            onChanged: (newHeating) {
                              setState(() => _lights = newHeating);

                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 24),
                            child: Text(
                              'Temperature',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 25,horizontal: 50),

                            child: Center(
                              child: SevenSegmentDisplay(
                                value: "25",
                                size: 8.0,
                                characterSpacing: 10.0,
                                backgroundColor: Colors.transparent,
                                segmentStyle: HexSegmentStyle(
                                  enabledColor: Colors.blueGrey.shade900,
                                  disabledColor: Colors.blueGrey.withOpacity(0.15),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 24),
                            child: Text(
                              'Air Condition',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,

                              ),
                            ),
                          ),
                          SwitchListTile(
                            value: _air,
                            onChanged: (newHeating) {
                              setState(() => _air = newHeating);
                            },
                          ),
                          Slider(
                            value: air,
                            onChanged: (newFan) {
                              setState(() => air = newFan);
                            },
                            max: 30,
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 24),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: const [
                                Text('16ْْْ°'),
                                Text('23°'),
                                Text('30°'),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 24),
                            child: Text(
                              'Curtain control',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,

                              ),
                            ),
                          ),
                          SwitchListTile(
                            value: _curtain,
                            onChanged: (newHeating) {
                              setState(() => _curtain = newHeating);
                            },
                          ),
                          Slider(
                            value: curtain,
                            onChanged: (newCurtain) {
                              setState(() => curtain = newCurtain);
                            },
                            max: 30,
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 24),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: const [
                                Text('0ْْْ%'),
                                Text('50%'),
                                Text('100%'),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }



  Widget _roundedButton({
    String title,
    bool isActive = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 12,
        horizontal: 32,
      ),
      decoration: BoxDecoration(
        color: isActive ? Colors.indigo : Colors.transparent,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.indigo),
      ),
      child: Text(
        title,
        style: TextStyle(
          color: isActive ? Colors.white : Colors.black,
        ),
      ),
    );
  }
}
