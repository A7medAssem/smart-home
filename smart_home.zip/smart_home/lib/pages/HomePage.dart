import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:smart_home/body/HomePageBody.dart';
import 'living_room.dart';
class HomePage extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery
        .of(context)
        .size;
    return Scaffold(

      body: HomePageBody(),

      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xffffffff),
        title: Text("Smart Home",
          style: TextStyle(color: Colors.blueGrey),
        ),

        leading: IconButton(
          icon: Icon(
            Icons.home,
            color: Colors.blueGrey,

          ),
          alignment: Alignment.center,
          onPressed: (){
            print("Icon Button clicked");
          },
        ),
      ),
      bottomNavigationBar: new Container(
        padding: EdgeInsets.all(0.0),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[

            Expanded(
              flex: 1,
              child: IconButton(
                onPressed: () {
                  print("Icon Button home clicked");
                },
                icon: Icon(Icons.home),
              ),
            ),
            Expanded(
              flex: 1,
              child: IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => LivingRoom()),
                    );
                  },
                icon: Icon(Icons.control_camera_outlined),
              ),
            ),
            Expanded(
              flex: 1,
              child: IconButton(
                onPressed: () {
                  SystemNavigator.pop(); //for Android from flutter/services.dart
                },
                icon: Icon(Icons.exit_to_app),


              ),
            ),
          ],
        ),
      ),

    );
  }
}
