import 'package:flutter/material.dart';
import 'package:smart_home/pages/HomePage.dart';


void main() {

  runApp(
      new MaterialApp(
        home:HomePage(),
        debugShowCheckedModeBanner: false,
      )
  );
}

