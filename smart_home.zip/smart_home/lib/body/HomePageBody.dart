import 'package:flutter/material.dart';

class HomePageBody extends StatefulWidget {
  @override
  _LandingScreenBodyState createState() => _LandingScreenBodyState();
}

class _LandingScreenBodyState extends State<HomePageBody> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery
        .of(context)
        .size;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.0),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
            children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: size.height * 0.0,),
                      SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: Expanded(
                          flex: 1,
                          child: Row(
                            children: [
                              Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                    height: 120,
                                    width: 120,
                                    child:ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset("assets/image/light.png",
                                          fit: BoxFit.cover),
                                    ),
                                  ),
                                  Text("Lighting\nSystem",
                                    style:TextStyle(color: Colors.black87,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ) ,
                                  ),
                                  IconButton(
                                      icon: Icon(
                                      Icons.help,
                                      color: Colors.blueGrey,),
                                      onPressed: (){showModalBottomSheet(context: context,
                                          builder: (context){
                                            return Column(
                                                children: [
                                                  Container(
                                                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                                    height: 120,
                                                    width: 120,
                                                    child:ClipRRect(
                                                      borderRadius: BorderRadius.circular(20),
                                                      child: Image.asset("assets/image/light.png",
                                                          fit: BoxFit.cover),
                                                    ),
                                                  ),
                                                  Text("Lighting system\n",
                                                    style:TextStyle(color: Colors.black87,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 25,
                                                    ) ,
                                                  ),
                                                  Text("Smart lighting is an advanced way to light your home",
                                                    style:TextStyle(color: Colors.black,
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 16,
                                                    ),
                                                  ),
                                                ],
                                              );
                                          }
                                      );
                                      }
                                  )
                                ],
                              ),
                              Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                    height: 120,
                                    width: 120,
                                    child:ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset("assets/image/security.png",
                                          fit: BoxFit.cover),
                                    ),
                                  ),
                                  Text("Security\nSystem",
                                    style:TextStyle(color: Colors.black87,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ) ,
                                  ),
                                  IconButton(
                                      icon: Icon(
                                        Icons.help,
                                        color: Colors.blueGrey,),
                                      onPressed: (){showModalBottomSheet(context: context,
                                          builder: (context){
                                            return Column(
                                              children: [
                                                Container(
                                                  padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                                  height: 120,
                                                  width: 120,
                                                  child:ClipRRect(
                                                    borderRadius: BorderRadius.circular(20),
                                                    child: Image.asset("assets/image/security.png",
                                                        fit: BoxFit.cover),
                                                  ),
                                                ),
                                                Text("Security System \n",
                                                  style:TextStyle(color: Colors.black87,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 25,
                                                  ) ,
                                                ),
                                                Text("it is literally a means or method by which something is secured through a system of interworking components and devices.",
                                                  style:TextStyle(color: Colors.black,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 16,
                                                  ) ,
                                                ),
                                              ],
                                            );
                                          }
                                        );
                                      }
                                  )
                                ],
                              ),
                              Column(
                                children: [
                                  Container(
                                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                    height: 120,
                                    width: 120,
                                    child:ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.asset("assets/image/garage.png",
                                          fit: BoxFit.cover),
                                    ),
                                  ),
                                  Text("Garage \nSystem",
                                    style:TextStyle(color: Colors.black87,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ) ,
                                  ),
                                  IconButton(
                                      icon: Icon(
                                        Icons.help,
                                        color: Colors.blueGrey,),
                                      onPressed: (){showModalBottomSheet(context: context,
                                          builder: (context){
                                            return Column(
                                              children: [
                                                Container(
                                                  padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                                  height: 120,
                                                  width: 120,
                                                  child:ClipRRect(
                                                    borderRadius: BorderRadius.circular(20),
                                                    child: Image.asset("assets/image/garage.png",
                                                        fit: BoxFit.cover),
                                                  ),
                                                ),
                                                Text("Garage System\n",
                                                  style:TextStyle(color: Colors.black87,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 25,
                                                  ) ,
                                                ),
                                                Text("Garage doors are an essential tool used by homeowners every day for safe.",
                                                  style:TextStyle(color: Colors.black,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 16,
                                                  ),
                                                ),
                                              ],
                                            );
                                          }
                                      );
                                      }
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                Row(
                  mainAxisAlignment:MainAxisAlignment.center ,
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                    height: 120,
                    width: 120,
                    child:ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset("assets/image/quar.png",
                          fit: BoxFit.cover),
                    ),
                  ),
                  Text("Quarantine\nRoom System",
                    style:TextStyle(color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 25,
                    ) ,
                  ),
                  IconButton(
                      icon: Icon(
                        Icons.help,
                        color: Colors.blueGrey,),
                      onPressed: (){showModalBottomSheet(context: context,
                          builder: (context){
                            return Column(
                              children: [
                                Container(
                                  padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                  height: 120,
                                  width: 120,
                                  child:ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Image.asset("assets/image/quar.png",
                                        fit: BoxFit.cover),
                                  ),
                                ),
                                Text("Quarantine Room System\n",
                                  style:TextStyle(color: Colors.black87,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 25,
                                  ) ,
                                ),
                                Text("is a designated location in your home designed to isolate people who have been exposed to a disease.",
                                  style:TextStyle(color: Colors.black,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                  ) ,
                                ),
                              ],
                            );
                          }
                      );
                      }
                  )
                ],
              ),
                Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: size.height * 0.0,),
                  SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Expanded(
                      flex: 1,
                      child: Row(
                        children: [
                          Column(
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                height: 120,
                                width: 120,
                                child:ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset("assets/image/fire.png",
                                      fit: BoxFit.cover),
                                ),
                              ),
                              Text("Fire\nDetection\nSystem",
                                style:TextStyle(color: Colors.black87,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ) ,
                              ),
                              IconButton(
                                  icon: Icon(
                                    Icons.help,
                                    color: Colors.blueGrey,),
                                  onPressed: (){showModalBottomSheet(context: context,
                                      builder: (context){
                                        return Column(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                              height: 120,
                                              width: 120,
                                              child:ClipRRect(
                                                borderRadius: BorderRadius.circular(20),
                                                child: Image.asset("assets/image/fire.png",
                                                    fit: BoxFit.cover),
                                              ),
                                            ),
                                            Text("Fire Detection System\n",
                                              style:TextStyle(color: Colors.black87,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 25,
                                              ) ,
                                            ),
                                            Text("is a system of integrated fire detection devices",
                                              style:TextStyle(color: Colors.black,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ],
                                        );
                                      }
                                  );
                                  }
                              )
                            ],
                          ),
                          Column(
                            children: [
                              Container(
                                padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                height: 120,
                                width: 120,
                                child:ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset("assets/image/temp.png",
                                      fit: BoxFit.cover),
                                ),
                              ),
                              Text("Temperature\nControl\nSystem",
                                style:TextStyle(color: Colors.black87,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25,
                                ) ,
                              ),
                              IconButton(
                                  icon: Icon(
                                    Icons.help,
                                    color: Colors.blueGrey,),
                                  onPressed: (){showModalBottomSheet(context: context,
                                      builder: (context){
                                        return Column(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                                              height: 120,
                                              width: 120,
                                              child:ClipRRect(
                                                borderRadius: BorderRadius.circular(20),
                                                child: Image.asset("assets/image/temp.png",
                                                    fit: BoxFit.cover),
                                              ),
                                            ),
                                            Text("Temperature Control System\n",
                                              style:TextStyle(color: Colors.black87,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 25,
                                              ) ,
                                            ),
                                            Text("device that detects and measures hotness and coolness and converts it into an electrical signal.",
                                              style:TextStyle(color: Colors.black,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                              ) ,
                                            ),
                                          ],
                                        );
                                      }
                                  );
                                  }
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

            ],
        ),

      ),

    );
  }
}