package com.example.smart_home

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
